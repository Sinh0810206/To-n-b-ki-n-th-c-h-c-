Đây là toàn bộ code dự án số 1 trong seri tự học lập trình HTML CSS tại http://tuhoc.cc link Figma dự án :
https://www.figma.com/file/3kHcuu3c8fvhnA2q2wUwBM/
